def velocidad(l: float, t: float) -> float:
    v = (l * t)
    return v


def aseleracion (l: float, t: float) -> float:
    a = (l * t)
    return a
