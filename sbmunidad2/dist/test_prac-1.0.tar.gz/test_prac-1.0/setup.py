from setuptools import setup

setup(
    name='test_prac',
    version='1.0',
    description='calcular el volumen negativo',
    author='SBMV',
    author_email='sa1992moc@gmail.com',
    url='www.google.com',
    py_modules=['test_prac'],
)
